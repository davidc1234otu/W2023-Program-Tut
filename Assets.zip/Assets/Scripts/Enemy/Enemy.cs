using UnityEngine;

public class Enemy : MonoBehaviour
{
    [SerializeField] Transform player;
    Rigidbody rb;

    public float maxHP = 10.0f;
    float currentHP = 10.0f;
    public int killPointVal = 50;
    public int expVal = 2;
    public float enemySpeed = 5.0f;
    public float contactDmg = 1.0f;

    Vector3 _dirToPlayer;
    bool calcThisFrame = false;

    private void Awake()
    {
        rb = GetComponent<Rigidbody>();

    }

    private void Start()
    {
        ResetHP();
    }

    private void Update()
    {
        UpdateEnemy();
    }

    private void LateUpdate()
    {
        calcThisFrame = false;
    }

    public virtual void UpdateEnemy()
    {
        rb.AddForce(Vector3.forward);
        KillIfDead();
    }

    public void ResetHP()
    {
        currentHP = maxHP;
    }

    public void TakeDamage(float damage)
    {
        currentHP -= damage;
    }

    public void HealDamage(float heal)
    {
        currentHP += heal;
        if (currentHP > maxHP)
        {
            currentHP = maxHP;
        }
    }

    public void KillIfDead()
    {
        if (CheckIfDead())
        {
            Destroy(gameObject);
        }
    }

    public bool CheckIfDead()
    {
        if (currentHP <= 0.0f)
        {
            return true;
        }
        
        return false;
    }

    public void TargetPlayer(Vector3 dirToPlayer)
    {
        rb.velocity = dirToPlayer.normalized * enemySpeed;
    }

    public void MoveAway(Vector3 dirToPlayer)
    {
        rb.velocity = dirToPlayer.normalized * -enemySpeed;
    }

    public Vector3 GetDirectionToPlayer()
    {
        Vector3 dirToPlayer;
        if (!calcThisFrame)
        {
            dirToPlayer = player.transform.position - transform.position;

            _dirToPlayer = dirToPlayer;

            calcThisFrame = true;
        }
        else
        {
            dirToPlayer = _dirToPlayer;
        }

        return dirToPlayer;
    }

    public float GetDistanceToPlayer()
    {
        return GetDirectionToPlayer().magnitude;
    }

    public void RotateTowardsDir(Vector3 dir)
    {
        float angle = Mathf.Atan2(-dir.x, dir.z) * Mathf.Rad2Deg;

        gameObject.transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);
    }

    private void OnCollisionStay(Collision collision)
    {
        if (collision.gameObject.layer == LayerMask.NameToLayer("Player"))
        {
            PlayerController player = collision.gameObject.GetComponent<PlayerController>();
            player.TakeDamage(contactDmg);
        }
    }

   
}
