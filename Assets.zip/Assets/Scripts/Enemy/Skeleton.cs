using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Skeleton : Enemy
{
    public override void UpdateEnemy()
    {
        base.UpdateEnemy();

        RotateTowardsDir(GetDirectionToPlayer());

        TargetPlayer(GetDirectionToPlayer());
    }
}
