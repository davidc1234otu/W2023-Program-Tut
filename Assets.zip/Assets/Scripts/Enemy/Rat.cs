using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rat : Enemy
{
    public override void UpdateEnemy()
    {
        base.UpdateEnemy();

        //RotateTowardsDir();
    }
}
