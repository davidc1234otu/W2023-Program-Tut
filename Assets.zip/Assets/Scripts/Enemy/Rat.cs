using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rat : Enemy
{
    public float fleeDist = 3.0f;

    public override void UpdateEnemy()
    {
        base.UpdateEnemy();

        RotateTowardsDir(GetDirectionToPlayer());

        if (GetDistanceToPlayer() < fleeDist)
        {
            MoveAway(GetDirectionToPlayer());
        }
        else
        {
            TargetPlayer(GetDirectionToPlayer());
        }
    }


}
