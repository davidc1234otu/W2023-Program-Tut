using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour
{
    public GameObject player;
    public Text playerHPDisplay;
    

    public float maxPlayerHP = 100.0f;
    float currentPlayerHP = 100.0f;
    public bool isDead = false;
    public Text deathMessage;
    Animation playDeathAnimation;

    public List<GameObject> weaponPrefabs;
    public GameObject weaponParent;
    public bool holdSwordL = false;
    public bool holdSwordR = false;
    private bool lastHeldWeapon = false;
    private int currentWeapon = -1;
    public GameObject weaponInHand = null;
    private bool swinging = false;

    private void Awake()
    {
        ResetHP();
    }

    void Update()
    {
        WeaponDisplayUpdate();
        UpdateHPDisplay();
        CheckIfDead();
        SwingWeapon();
        if (swinging)
        {
            SwingWeapon();
        }
    }

    public void ResetHP()
    {
        currentPlayerHP = maxPlayerHP;
    }

    public void TakeDamage(float damage)
    {
        currentPlayerHP -= damage;
    }

    public void HealDamage(float heal)
    {
        currentPlayerHP += heal;
        if (currentPlayerHP > maxPlayerHP)
        {
            currentPlayerHP = maxPlayerHP;
        }
    }

    private void WeaponDisplayUpdate()
    {
        if (lastHeldWeapon != holdSwordR)
        {

        }

        lastHeldWeapon = holdSwordR;
    }

    private void UpdateHPDisplay()
    {
        if (playerHPDisplay != null)
        {
            playerHPDisplay.text = currentPlayerHP.ToString();
        }
    }

    public void CheckIfDead()
    {
        if (currentPlayerHP <= 0.0f && !isDead)
        {
            currentPlayerHP = 0.0f;
            Die();
        }
    }

    private void Die()
    {
        isDead = true;
        deathMessage.gameObject.SetActive(true);
        Time.timeScale = 0.0f;

    }

    private void SwingWeapon()
    {
        if (weaponInHand != null)
        {

        }
    }

}
