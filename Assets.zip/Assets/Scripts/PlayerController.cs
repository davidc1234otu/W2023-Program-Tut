using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour, IDataPersistence
{
    public GameObject player;
    public Text playerHPDisplay;
    

    public float maxPlayerHP = 100.0f;
    public float currentPlayerHP = 100.0f;
    public bool isDead = false;
    public Text deathMessage;
    Animation playDeathAnimation;

    public List<GameObject> weaponPrefabs;
    public GameObject weaponParent;
    public bool holdSwordL = false;
    public bool holdSwordR = false;
    private bool lastHeldWeapon = false;
    private int currentWeapon = -1;
    public GameObject weaponInHand = null;
    private bool swinging = false;

    public event System.Action<float, float> OnHealthChanged;

    private void Awake()
    {
        ResetHP();
        StartCoroutine(HealthIncrease());
    }

    void Update()
    {
        WeaponDisplayUpdate();
        UpdateHPDisplay();
        CheckIfDead();
        SwingWeapon();
        if (swinging)
        {
            SwingWeapon();
        }
        WeaponInput();

        if (Input.GetKey(KeyCode.E))
        {
            currentPlayerHP -= 5;
        }

    }

    private void WeaponInput()
    {
        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            CycleDownWeapons();
        }
        if (Input.GetKeyDown(KeyCode.Alpha2))
        {
            CycleUpWeapons();
        }
    }

    private void CycleUpWeapons()
    {
        if(currentWeapon == weaponPrefabs.Count - 1)
        {
            UnequipWeapon();
        }
        else
        {
            EquipWeapon(currentWeapon + 1);
        }
    }

    private void CycleDownWeapons()
    {
        if(currentWeapon == -1)
        {
            EquipWeapon(weaponPrefabs.Count - 1);
        }
        else if(currentWeapon == 0)
        {
            UnequipWeapon();
        }
        else
        {
            EquipWeapon(currentWeapon - 1);
        }
    }
    private void UnequipWeapon()
    {
        if (weaponParent.transform.childCount > 0)
        {
            Destroy(weaponParent.transform.GetChild(0).gameObject);
            weaponInHand = null;
        }
        holdSwordR = false;
        currentWeapon = -1;
    }

    private void EquipWeapon(int num)
    {
        if(currentWeapon != num)
        {
            UnequipWeapon();

            holdSwordR = true;

            if (num < weaponPrefabs.Count)
            {
                weaponInHand =  Instantiate(weaponPrefabs[num], weaponParent.transform);
            }

            currentWeapon = num;
        }
    }


    public void ResetHP()
    {
        currentPlayerHP = maxPlayerHP;
    }

    public void TakeDamage(float damage)
    {
        currentPlayerHP -= damage;
    }

    public virtual void RestoreHealth(int restore)
    {
        currentPlayerHP = Mathf.Clamp(currentPlayerHP + restore, 0, maxPlayerHP);

        Debug.Log(currentPlayerHP);

        if (OnHealthChanged != null)
        {
            OnHealthChanged(maxPlayerHP, currentPlayerHP);
        }
    }

    IEnumerator HealthIncrease()
    {
        Debug.Log("Start Coroutine");

        for (int x = 1; x <= maxPlayerHP; x++)
        {
            currentPlayerHP = x;
            if (OnHealthChanged != null)
            {
                OnHealthChanged(maxPlayerHP, currentPlayerHP);
            }

            yield return new WaitForSeconds(0.01f);
            Debug.Log("HP: " + currentPlayerHP + " / " + maxPlayerHP);
        }

        Debug.Log("Current HP is " + currentPlayerHP);
        Debug.Log("End of Coroutine");
    }

    private void WeaponDisplayUpdate()
    {
        if (lastHeldWeapon != holdSwordR)
        {

        }

        lastHeldWeapon = holdSwordR;
    }

    private void UpdateHPDisplay()
    {
        if (playerHPDisplay != null)
        {
            playerHPDisplay.text = currentPlayerHP.ToString();
        }
    }

    public void CheckIfDead()
    {
        if (currentPlayerHP <= 0.0f && !isDead)
        {
            currentPlayerHP = 0.0f;
            Die();
        }
    }

    private void Die()
    {
        isDead = true;
        deathMessage.gameObject.SetActive(true);
        Time.timeScale = 0.0f;

    }

    private void SwingWeapon()
    {
        if (weaponInHand != null)
        {

        }
    }

    public void SaveData(ref GameData data)
    {
        data.playerPosition = transform.position;
    }

    public void LoadData(GameData data)
    {
        transform.position = data.playerPosition;
    }

}
