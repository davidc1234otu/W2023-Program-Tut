using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Potion : MonoBehaviour
{
    private Collectable potion;

    private void Start()
    {
        potion = new Collectable("potion", 1, 5);
    }

    private void OnCollisionEnter(Collision other)
    {
        if (other.collider.tag == "Player")
        {
            potion.UpdateHealth();
            potion.UpdateScore();
            Destroy(gameObject);
        }
    }
}
