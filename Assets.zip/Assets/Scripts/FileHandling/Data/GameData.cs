using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.PlayerLoop;

[System.Serializable]
public class GameData
{
    public int score;
    public Vector3 playerPosition;

    // Default values
    public GameData()
    {
        this.score = 0;
        this.playerPosition = new Vector3(6, 6, -6);
    }

}
