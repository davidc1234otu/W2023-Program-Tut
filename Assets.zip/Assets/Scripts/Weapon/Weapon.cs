using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Weapon : MonoBehaviour
{
    public AudioClip atkSFX;

    public float atkSpd;
    protected float timeSinceAtk = 0.0f;
    protected bool canAtk = true;

    public abstract void Attack();

    public void UpdateCanAttack()
    {
        if (!canAtk)
        {
            timeSinceAtk += Time.deltaTime;

            if (timeSinceAtk > atkSpd)
            {
                canAtk = true;
                timeSinceAtk = 0.0f;
            }
        }
    }

}
