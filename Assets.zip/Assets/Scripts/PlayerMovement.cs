using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    private PlayerController controller;
    private Vector3 playerVelocity;
    private bool groundedPlayer;
    Transform trans;
    Rigidbody body;

    [SerializeField] float speed; 
    [SerializeField] float jumpForce;

    bool jumpInput;
    bool isGrounded;
    bool isWalking;


    // Start is called before the first frame update
    void Start()
    {
        trans = GetComponent<Transform>();
        body = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        walk();
        if (Input.GetKeyDown(KeyCode.Space))
        {
            jumpInput = true;
        }
        if (Input.GetKeyUp(KeyCode.Space))
        {
            jumpInput = false;
        }
    }
    void FixedUpdate() // it's meant for any physics updates
    {
        if (jumpInput)
        {
            jump();
        }
        // jump();
    }
    void walk()
    {
        if (Input.GetKey(KeyCode.W))
        {
            trans.position += transform.forward * Time.deltaTime * speed; 
            trans.rotation = Quaternion.Euler(0, 0, 0); 
            isWalking = true;
        }
        if (Input.GetKey(KeyCode.S))
        {
            trans.position -= transform.forward * Time.deltaTime * speed; 
            trans.rotation = Quaternion.Euler(0, 0, 0); 
            isWalking = true;
        }
        if (Input.GetKey(KeyCode.D)) 
        {
            trans.position += transform.right * Time.deltaTime * speed; 
            trans.rotation = Quaternion.Euler(0, 0, 0); 
            isWalking = true;
        }
        if (Input.GetKey(KeyCode.A))
        {
            trans.position -= transform.right * Time.deltaTime * speed;
            trans.rotation = Quaternion.Euler(0, 0, 0); 
            isWalking = true;
        }
        if (!Input.GetKey(KeyCode.A) && !Input.GetKey(KeyCode.D) && !Input.GetKey(KeyCode.S) && !Input.GetKey(KeyCode.W))
        {
            isWalking = false;
        }


    }
    void jump()
    {
        /* if (Input.GetKey(KeyCode.Space))
         {
             body.AddForce(transform.up * jumpForce, ForceMode2D.Impulse);
         }
         it's always jumped
        */
        if (isGrounded == true)
        {
            body.AddForce(transform.up * jumpForce, ForceMode.Impulse);
            isGrounded = false;
        }
        


    }

    void OnCollisionEnter2D(Collision2D collision) // detects when the object collides with another object
    {
        if (collision.collider.tag == "Ground") // saying if the thing you're colliding with has the ground tag on it
        {
            for (int i = 0; i < collision.contacts.Length; i++) // if any one of the collisions is on the ground
            {
                if (collision.contacts[i].normal.y > 0.5)
                {
                    isGrounded = true;
                }
            }
        }
    }
}
